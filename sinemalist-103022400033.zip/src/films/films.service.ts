import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateFilmDto } from './dto/create-film.dto.js';
import { UpdateFilmDto } from './dto/update-film.dto.js';
import { randomUUID } from 'crypto';

export interface Film {
  id: string;
  judul: string;
  genre: string;
  tahun: number;
  rating: number;
  sudahDitonton: boolean;
}

@Injectable()
export class FilmsService {
  private films: Film[] = [
    { id: "1", judul: "Laskar Pelangi", genre: "Drama", tahun: 2008, rating: 8.1, sudahDitonton: true },
    { id: "2", judul: "Ada Apa dengan Cinta?", genre: "Romansa", tahun: 2002, rating: 7.7, sudahDitonton: true },
    { id: "3", judul: "Pengabdi Setan", genre: "Horor", tahun: 2017, rating: 6.6, sudahDitonton: false },
    { id: "4", judul: "Keluarga Cemara", genre: "Drama", tahun: 2019, rating: 7.8, sudahDitonton: false },
    { id: "5", judul: "Ngeri-Ngeri Sedap", genre: "Komedi", tahun: 2022, rating: 8.0, sudahDitonton: true },
    { id: "6", judul: "Dilan 1990", genre: "Romansa", tahun: 2018, rating: 7.0, sudahDitonton: false }
  ];

  findAll(sudahDitonton?: boolean): Film[] {
    if (sudahDitonton !== undefined) {
      return this.films.filter(film => film.sudahDitonton === sudahDitonton);
    }
    return this.films;
  }

  findOne(id: string): Film {
    const film = this.films.find(f => f.id === id);
    if (!film) {
      throw new NotFoundException(`Film dengan id ${id} tidak ditemukan`);
    }
    return film;
  }

  create(createFilmDto: CreateFilmDto): Film {
    const newFilm: Film = {
      id: randomUUID(),
      judul: createFilmDto.judul,
      genre: createFilmDto.genre,
      tahun: createFilmDto.tahun,
      rating: createFilmDto.rating,
      sudahDitonton: createFilmDto.sudahDitonton ?? false,
    };
    this.films.push(newFilm);
    return newFilm;
  }

  update(id: string, updateFilmDto: UpdateFilmDto): Film {
    const film = this.findOne(id);
    
    if (updateFilmDto.sudahDitonton !== undefined) {
      film.sudahDitonton = updateFilmDto.sudahDitonton;
    }
    
    return film;
  }

  remove(id: string): void {
    const filmIndex = this.films.findIndex(f => f.id === id);
    if (filmIndex === -1) {
      throw new NotFoundException(`Film dengan id ${id} tidak ditemukan`);
    }
    this.films.splice(filmIndex, 1);
  }
}